from flask import Flask, render_template, request
from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS
import pandas as pd
from sklearn.linear_model import LinearRegression
from datetime import datetime, timedelta

app = Flask(__name__)

# Конфигурация InfluxDB
INFLUXDB_URL = "http://influxdb:8086"
INFLUXDB_TOKEN = "my-super-secret-token"
INFLUXDB_ORG = "my-org"
INFLUXDB_BUCKET = "my-bucket"

client = InfluxDBClient(url=INFLUXDB_URL, token=INFLUXDB_TOKEN, org=INFLUXDB_ORG)
write_api = client.write_api(write_options=SYNCHRONOUS)
query_api = client.query_api()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/record', methods=['POST'])
def record_visit():
    # Запись данных о посещаемости
    point = Point("visits").tag("location", "main").field("count", 1)
    write_api.write(bucket=INFLUXDB_BUCKET, record=point)
    return "Visit recorded!"

@app.route('/analytics')
def analytics():
    # Получение данных о посещаемости
    query = f'''
    from(bucket: "{INFLUXDB_BUCKET}")
      |> range(start: -30d)
      |> filter(fn: (r) => r._measurement == "visits")
      |> aggregateWindow(every: 1d, fn: sum, createEmpty: false)
    '''
    result = query_api.query(query)

    # Преобразование данных в DataFrame
    data = []
    for table in result:
        for record in table.records:
            data.append({
                "time": record.get_time(),
                "count": record.get_value()
            })
    df = pd.DataFrame(data)

    # Прогнозирование посещаемости на следующий месяц
    if not df.empty:
        df['time'] = pd.to_datetime(df['time'])
        df['days'] = (df['time'] - df['time'].min()).dt.days
        model = LinearRegression()
        model.fit(df[['days']], df['count'])
        future_days = df['days'].max() + 30
        predicted_count = model.predict([[future_days]])[0]
    else:
        predicted_count = 0

    return render_template('analytics.html', visits=df.to_dict('records'), predicted_count=int(predicted_count))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)